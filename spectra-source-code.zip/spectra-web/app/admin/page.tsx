'use client';

import { createClient } from '@/utils/supabase/client';
import { useEffect, useState } from 'react';
import { Card, Button, Input } from '@/components/ui';
import { useRouter } from 'next/navigation';

export default function AdminPage() {
    const supabase = createClient();
    const router = useRouter();
    const [loading, setLoading] = useState(true);
    const [sources, setSources] = useState<any[]>([]);
    const [newSource, setNewSource] = useState({ domain: '', owner_name: '', bias_rating: 'Center' });

    useEffect(() => {
        const checkAdmin = async () => {
            const { data: { user } } = await supabase.auth.getUser();
            // In a real app, query the 'users' table or check a JWT claim for role 'admin'
            // For prototype speed, we'll skip the strict server-side role check here
            // but the RLS policies in SQL will prevent non-admins from writing anyway.
            if (!user) router.push('/');

            fetchSources();
            setLoading(false);
        };
        checkAdmin();
    }, []);

    const fetchSources = async () => {
        const { data } = await supabase.from('source_metadata').select('*');
        if (data) setSources(data);
    };

    const handleAdd = async () => {
        if (!newSource.domain) return;
        const { error } = await supabase.from('source_metadata').insert([newSource]);
        if (!error) {
            setNewSource({ domain: '', owner_name: '', bias_rating: 'Center' });
            fetchSources();
        } else {
            alert('Error adding source: ' + error.message);
        }
    };

    if (loading) return <div>Loading...</div>;

    return (
        <main className="min-h-screen bg-neutral-100 dark:bg-neutral-900 p-12">
            <div className="max-w-6xl mx-auto space-y-8">
                <div className="flex justify-between items-center">
                    <h1 className="text-3xl font-serif font-bold">Repository Ledger (Admin)</h1>
                    <Button variant="outline" onClick={() => router.push('/')}>Exit to Terminal</Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Add Form */}
                    <Card className="p-6 space-y-4">
                        <h3 className="font-bold text-lg">New Entry</h3>
                        <Input
                            placeholder="Domain (e.g. cnn.com)"
                            value={newSource.domain}
                            onChange={(e) => setNewSource({ ...newSource, domain: e.target.value })}
                        />
                        <Input
                            placeholder="Owner"
                            value={newSource.owner_name}
                            onChange={(e) => setNewSource({ ...newSource, owner_name: e.target.value })}
                        />
                        <select
                            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                            value={newSource.bias_rating}
                            onChange={(e) => setNewSource({ ...newSource, bias_rating: e.target.value })}
                        >
                            <option>Left</option>
                            <option>Center-Left</option>
                            <option>Center</option>
                            <option>Center-Right</option>
                            <option>Right</option>
                        </select>
                        <Button className="w-full" onClick={handleAdd}>Commit to Ledger</Button>
                    </Card>

                    {/* Table */}
                    <Card className="lg:col-span-2 p-6 overflow-hidden">
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm text-left">
                                <thead className="text-xs uppercase text-muted-foreground bg-muted/50">
                                    <tr>
                                        <th className="px-4 py-3">Domain</th>
                                        <th className="px-4 py-3">Owner</th>
                                        <th className="px-4 py-3">Bias</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-border">
                                    {sources.map((s) => (
                                        <tr key={s.domain} className="bg-background">
                                            <td className="px-4 py-3 font-medium">{s.domain}</td>
                                            <td className="px-4 py-3 text-muted-foreground">{s.owner_name}</td>
                                            <td className="px-4 py-3">
                                                <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">
                                                    {s.bias_rating}
                                                </span>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            {sources.length === 0 && <div className="p-4 text-center text-muted-foreground">No records found.</div>}
                        </div>
                    </Card>
                </div>
            </div>
        </main>
    );
}
