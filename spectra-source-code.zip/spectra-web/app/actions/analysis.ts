'use server';

import Groq from 'groq-sdk';

const groq = new Groq({
    apiKey: process.env.GROQ_API_KEY,
});

export async function analyzeContent(content: string, url?: string) {
    if (!content && !url) return { error: "No content provided" };

    try {
        // 1. Serper.dev Corroboration Check (Mocked for now or implemented if key is valid)
        // In a real implementation: fetch(`https://google.serper.dev/search`, ...)
        const corroborationScore = await checkCorroboration(content);

        // 2. Groq Llama-3 Analysis for Language Intensity & Fallacies
        const completion = await groq.chat.completions.create({
            messages: [
                {
                    role: "system",
                    content: `You are an expert media literacy analyst. Analyze the provided news text for:
                    1. Emotional intensity (0-100, where 100 is highly inflammatory).
                    2. Logical fallacies (list them).
                    3. Overall objectivity (0-100).
                    
                    Return JSON: { "intensity": number, "fallacies": string[], "objectivity": number, "summary": "string" }`
                },
                {
                    role: "user",
                    content: content.substring(0, 2000) // Truncate for token limits
                }
            ],
            model: "llama3-8b-8192",
            response_format: { type: "json_object" }
        });

        const analysis = JSON.parse(completion.choices[0]?.message?.content || '{}');

        // 3. Final Score Calculation
        // Formula: (Corroboration * 0.4) + (Objectivity * 0.3) + (SourceHistory * 0.3)
        // We'll assume SourceHistory is neutral (50) for this independent check
        const weightedScore = Math.round(
            (corroborationScore * 0.4) +
            ((analysis.objectivity || 50) * 0.3) +
            (50 * 0.3)
        );

        return {
            score: weightedScore,
            metrics: {
                corroboration: corroborationScore,
                language: analysis.intensity || 50, // Display logic might need inversion depending on UI
                history: 50 // Placeholder until we query DB
            },
            details: analysis
        };

    } catch (error) {
        console.error("Analysis failed:", error);
        return { error: "Analysis failed" };
    }
}

async function checkCorroboration(query: string): Promise<number> {
    if (!process.env.SERPER_API_KEY) return 50; // Default if no key

    try {
        const response = await fetch("https://google.serper.dev/search", {
            method: "POST",
            headers: {
                "X-API-KEY": process.env.SERPER_API_KEY,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ q: query.substring(0, 200) }) // Search first snippet
        });

        const data = await response.json();
        // Simple heuristic: If top results mimic the query topic from credible domains, high score.
        // For this MVP, we just count result quantity as a proxy for 'buzz' or match.
        // Real logic would check domain allowlists.
        return Math.min((data.organic?.length || 0) * 10, 100);
    } catch (e) {
        return 50;
    }
}

export async function rewriteHeadline(headline: string) {
    try {
        const completion = await groq.chat.completions.create({
            messages: [
                {
                    role: "system",
                    content: "Rewrite this headline to be purely factual, neutral, and devoid of sensation or clickbait. Return only the new headline."
                },
                {
                    role: "user",
                    content: headline
                }
            ],
            model: "llama3-8b-8192",
        });
        return completion.choices[0]?.message?.content || headline;
    } catch (error) {
        return headline;
    }
}
