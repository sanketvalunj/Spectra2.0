import Header from '@/components/Header';
import { Card } from '@/components/ui';
import { ArrowUpRight } from 'lucide-react';

export default function Home() {
  return (
    <main className="min-h-screen bg-neutral-100 dark:bg-neutral-900 pattern-grid-lg">
      < Header />

      <section className="container max-w-screen-2xl py-12 space-y-12">

  {/* Initial Hero / Banner */ }
  <div className="text-center space-y-4 py-8 border-b-2 border-primary/20">
    < div className ="flex justify-between items-center text-xs font-mono uppercase tracking-widest text-muted-foreground">
      < span > Est.October 2024</span >
        <span className="text-primary font-bold">Special Glass Edition</span>
          < span > Price: One Coin</span >
            </div >
    <h1 className="text-7xl md:text-9xl font-serif font-black tracking-tighter text-foreground uppercase pt-4 leading-[0.8]">
                Smart News Feed
            </h1 >
    <p className="text-xl md:text-2xl font-serif italic text-muted-foreground">
                A retro - modern lens for the digital age: automated truth, expertly clarified.
            </p >
        </div >

    {/* Main Content Grid */ }
    < div className ="grid grid-cols-1 lg:grid-cols-12 gap-8">

  {/* Main Headline */ }
  <div className="lg:col-span-8 space-y-8">
    < Card className ="group relative overflow-hidden border-none shadow-2xl h-[600px] flex flex-col justify-end p-8 text-white">
      < div className ="absolute inset-0 z-0 bg-neutral-800">
  {/* Placeholder for Main Image */ }
  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent z-10" />
  {/* We would use next/image here in real app */ }
  <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2670&auto=format&fit=crop" alt="City" className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700" />
                    </div >

    <div className="relative z-20 space-y-4 max-w-2xl">
      < div className ="flex items-center gap-2">
        < span className ="bg-primary text-primary-foreground px-2 py-1 text-xs font-bold uppercase tracking-widest">Verified</span>
          < span className ="text-xs font-mono uppercase text-white/70">The Guardian • 2h Ago</span>
                        </div >
    <h2 className="text-5xl font-serif font-bold leading-tight">
                            Global Tech Regulation Hits New Peak
                        </h2 >
    <p className="text-lg text-white/80 font-serif leading-relaxed line-clamp-3">
                            New frameworks aim to address generative AI safety and cross - border data privacy protocols.Industry experts suggest this alignment may redefine the digital landscape for the next decade.
                        </p >
    <button className="flex items-center gap-2 text-sm uppercase tracking-widest font-bold hover:text-primary transition-colors hover:underline">
                            Read Full Dossier < ArrowUpRight className ="w-4 h-4" />
                        </button >
                    </div >
                </Card >

    {/* Secondary Grid */ }
    < div className ="grid grid-cols-1 md:grid-cols-2 gap-8">
  {/* Article 2 */ }
  <Card className="p-6 space-y-4 hover:border-primary/50 transition-colors cursor-pointer">
    < div className ="h-48 bg-neutral-200 rounded-md mb-4 overflow-hidden">
      < img src ="https://images.unsplash.com/photo-1526304640152-d4619684e484?q=80&w=2670&auto=format&fit=crop" alt="Finance" className="w-full h-full object-cover" />
                        </div >
    <span className="text-xs font-mono uppercase text-primary">Financial Times</span>
      < h3 className ="text-2xl font-serif font-bold">Central Banking Trajectory</h3>
        < p className ="text-muted-foreground text-sm line-clamp-3">Market analysts predict a huge shift in fiscal posture as inflation metrics stabilize.</p>
                     </Card >

    {/* Article 3 */ }
    < Card className ="p-6 space-y-4 hover:border-primary/50 transition-colors cursor-pointer">
      < div className ="h-48 bg-neutral-200 rounded-md mb-4 overflow-hidden">
        < img src ="https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2672&auto=format&fit=crop" alt="Space" className="w-full h-full object-cover" />
                        </div >
    <span className="text-xs font-mono uppercase text-primary">Al Jazeera</span>
      < h3 className ="text-2xl font-serif font-bold">Lunar Base Phase II</h3>
        < p className ="text-muted-foreground text-sm line-clamp-3">Infrastructure deployment schedule finalized for the first permanent lunar habitat module.</p>
                     </Card >
                </div >
            </div >

    {/* Sidebar / Flash Despatches */ }
    < div className ="lg:col-span-4 space-y-8">
      < Card className ="p-8 bg-primary/5 border-primary/20 h-full">
        < h3 className ="font-serif text-3xl font-bold mb-8 border-b border-primary/20 pb-4 text-primary">Flash Despatches</h3>

          < div className ="space-y-8">
  {
    [1, 2, 3, 4].map((i) => (
      <div key={i} className="group cursor-pointer">
    < div className ="flex justify-between items-baseline mb-1">
    < span className ="text-[0.65rem] font-mono uppercase text-muted-foreground">The Verge Labs</span>
    < div className ="w-16 h-px bg-border group-hover:bg-primary transition-colors" />
                                </div >
      <h4 className="font-serif text-xl font-bold group-hover:text-primary transition-colors">Grid Optimization AI</h4>
    < p className ="text-xs text-muted-foreground mt-2 italic">Efficiency gains of 40% recorded in pilot cities.</p>
                            </div >
                        ))
  }
                    </div >
                </Card >
            </div >

        </div >
      </section >
    </main >
  );
}
