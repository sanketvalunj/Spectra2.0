'use client';

import { useState } from 'react';
import { Button, Input, Card } from '@/components/ui';
import { TrustReport } from '@/components/TrustReport';
import { analyzeContent, rewriteHeadline } from '@/app/actions/analysis';
import { VisualLieDetector } from '@/components/VisualLieDetector';
import { ArrowRight, Sparkles, AlertTriangle } from 'lucide-react';

export default function AnalyzePage() {
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const [result, setResult] = useState<any>(null);
    const [neutralized, setNeutralized] = useState<string | null>(null);

    const handleAnalyze = async () => {
        setLoading(true);
        setNeutralized(null);
        const data = await analyzeContent(input);
        setResult(data);
        setLoading(false);
    };

    const handleNeutralize = async () => {
        if (!input) return;
        const newHeadline = await rewriteHeadline(input);
        setNeutralized(newHeadline);
    };

    return (
        <main className="min-h-screen bg-neutral-100 dark:bg-neutral-900 pattern-grid-lg flex flex-col items-center py-12 px-4">
            <div className="w-full max-w-4xl space-y-8">
                <div className="text-center space-y-2">
                    <h1 className="text-4xl font-serif font-black uppercase text-foreground">Glass Box Engine</h1>
                    <p className="text-muted-foreground font-mono text-sm">Input data stream for credibility audit.</p>
                </div>

                <div className="flex gap-2">
                    <Input
                        placeholder="Paste headline or URL here..."
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        className="h-14 text-lg"
                    />
                    <Button size="lg" className="h-14 px-8" onClick={handleAnalyze} disabled={loading}>
                        {loading ? 'Scanning...' : 'Analyze'} <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                </div>

                {/* Visual Lie Detector Module */}
                <VisualLieDetector />

                {result && !result.error && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-accordion-down">
                        <div className="space-y-6">
                            <TrustReport score={result.score} metrics={result.metrics} />

                            {/* Actions */}
                            <Card className="p-6 space-y-4">
                                <h3 className="font-bold font-serif text-xl border-b pb-2">Heuristic Override</h3>
                                <div className="flex flex-col gap-3">
                                    <Button variant="outline" onClick={handleNeutralize} className="justify-between group">
                                        <span className="flex items-center gap-2"><Sparkles className="w-4 h-4 text-primary" /> De-sensationalize</span>
                                        <span className="text-[0.6rem] uppercase tracking-widest text-muted-foreground group-hover:text-foreground">AI Rewrite</span>
                                    </Button>
                                    {neutralized && (
                                        <div className="p-3 bg-primary/10 border border-primary/20 rounded-md text-sm font-medium">
                                            "{neutralized}"
                                        </div>
                                    )}
                                </div>
                            </Card>
                        </div>

                        <div className="space-y-6">
                            <Card className="p-6 h-full border-l-4 border-l-red-500">
                                <div className="flex items-center gap-2 mb-4 text-red-500">
                                    <AlertTriangle className="w-5 h-5" />
                                    <h3 className="font-bold uppercase tracking-widest text-sm">Detected Fallacies</h3>
                                </div>
                                {result.details?.fallacies?.length > 0 ? (
                                    <ul className="space-y-3">
                                        {result.details.fallacies.map((f: string, i: number) => (
                                            <li key={i} className="flex gap-2 items-start text-sm">
                                                <span className="text-red-500 font-mono text-xs mt-1">[{String(i + 1).padStart(2, '0')}]</span>
                                                <span className="text-muted-foreground">{f}</span>
                                            </li>
                                        ))}
                                    </ul>
                                ) : (
                                    <p className="text-muted-foreground italic">No logical fallacies detected in this sample.</p>
                                )}
                            </Card>
                        </div>
                    </div>
                )}
            </div>
        </main>
    );
}
