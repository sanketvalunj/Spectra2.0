'use client';

import { useState, useRef, useEffect } from 'react';
import { Button, Card } from '@/components/ui';
import { Upload, Eye, EyeOff, AlertTriangle } from 'lucide-react';

export function VisualLieDetector() {
    const [image, setImage] = useState<string | null>(null);
    const [analyzing, setAnalyzing] = useState(false);
    const [showHeatmap, setShowHeatmap] = useState(false);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const heatmapRef = useRef<HTMLCanvasElement>(null);

    const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const reader = new FileReader();
            reader.onload = (event) => {
                setImage(event.target?.result as string);
                setShowHeatmap(false);
            };
            reader.readAsDataURL(e.target.files[0]);
        }
    };

    const runELA = async () => {
        if (!image || !canvasRef.current || !heatmapRef.current) return;
        setAnalyzing(true);

        const img = new Image();
        img.src = image;
        img.onload = () => {
            const canvas = canvasRef.current!;
            const ctx = canvas.getContext('2d')!;
            const heatmapCanvas = heatmapRef.current!;
            const heatmapCtx = heatmapCanvas.getContext('2d')!;

            // 1. Set dimensions
            canvas.width = img.width;
            canvas.height = img.height;
            heatmapCanvas.width = img.width;
            heatmapCanvas.height = img.height;

            // 2. Draw original
            ctx.drawImage(img, 0, 0);

            // 3. ELA Algorithm: Re-compress and compare
            // To simulate "re-save", we can't easily generate a Blob and re-read it synchronously in pure client-side quickly without some async delay,
            // but for a "Glass" visual effect we can do a pixel difference simulation or use toDataURL with jpeg quality.

            const originalData = ctx.getImageData(0, 0, canvas.width, canvas.height);

            // Create a temporary re-compressed version
            const jpegquality = 0.90; // 90% quality
            const compressedUrl = canvas.toDataURL('image/jpeg', jpegquality);

            const compressedImg = new Image();
            compressedImg.src = compressedUrl;
            compressedImg.onload = () => {
                // Draw compressed to a temp canvas to read data
                const tempCanvas = document.createElement('canvas');
                tempCanvas.width = canvas.width;
                tempCanvas.height = canvas.height;
                const tempCtx = tempCanvas.getContext('2d')!;
                tempCtx.drawImage(compressedImg, 0, 0);

                const compressedData = tempCtx.getImageData(0, 0, canvas.width, canvas.height);
                const heatmapData = heatmapCtx.createImageData(canvas.width, canvas.height);

                // Compare pixels
                for (let i = 0; i < originalData.data.length; i += 4) {
                    // Diff per channel
                    const rDiff = Math.abs(originalData.data[i] - compressedData.data[i]);
                    const gDiff = Math.abs(originalData.data[i + 1] - compressedData.data[i + 1]);
                    const bDiff = Math.abs(originalData.data[i + 2] - compressedData.data[i + 2]);

                    // Amplify the difference for visibility (ELA Scale)
                    const scale = 20;
                    const avgDiff = (rDiff + gDiff + bDiff) / 3;
                    const val = Math.min(255, avgDiff * scale);

                    // Heatmap coloring: High diff = Red/White, Low = Black/Blue
                    // Simple grayscale for ELA usually, but let's make it sci-fi "Spectra" style
                    // If val is high -> Anomalies (White/Red)

                    heatmapData.data[i] = val;     // R
                    heatmapData.data[i + 1] = val;   // G
                    heatmapData.data[i + 2] = val;   // B
                    heatmapData.data[i + 3] = 255;   // Alpha
                }

                heatmapCtx.putImageData(heatmapData, 0, 0);
                setAnalyzing(false);
                setShowHeatmap(true);
            };
        };
    };

    return (
        <Card className="p-6 space-y-6 glass-card border border-primary/20">
            <div className="flex items-center justify-between">
                <h3 className="font-serif text-2xl font-bold flex items-center gap-2">
                    Visual Lie Detector <span className="text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded font-mono">BETA</span>
                </h3>
                <div className="relative">
                    <input
                        type="file"
                        accept="image/*"
                        onChange={handleUpload}
                        className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                    <Button variant="outline" size="sm">
                        <Upload className="w-4 h-4 mr-2" /> Upload Image
                    </Button>
                </div>
            </div>

            <div className="relative aspect-video bg-neutral-900 rounded-lg overflow-hidden flex items-center justify-center border border-white/10">
                {!image && (
                    <div className="text-center text-muted-foreground p-8">
                        <AlertTriangle className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p className="uppercase tracking-widest text-xs">Awaiting Evidence</p>
                    </div>
                )}

                {/* Original Image Canvas */}
                <canvas
                    ref={canvasRef}
                    className={`max-w-full max-h-[500px] object-contain transition-opacity duration-500 ${image && !showHeatmap ? 'opacity-100' : 'opacity-0'} absolute inset-0 m-auto`}
                />

                {/* Heatmap Overlay */}
                <canvas
                    ref={heatmapRef}
                    className={`max-w-full max-h-[500px] object-contain mix-blend-screen transition-opacity duration-500 ${showHeatmap ? 'opacity-100' : 'opacity-0'} absolute inset-0 m-auto`}
                />
            </div>

            {image && (
                <div className="flex justify-end gap-2">
                    <Button variant="ghost" onClick={() => setShowHeatmap(!showHeatmap)}>
                        {showHeatmap ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
                        {showHeatmap ? 'Hide Analysis' : 'Show ELA Heatmap'}
                    </Button>
                    <Button onClick={runELA} disabled={analyzing} className={analyzing ? "animate-pulse" : ""}>
                        {analyzing ? 'Scanning Pixels...' : 'Run Error Level Analysis'}
                    </Button>
                </div>
            )}

            <div className="text-xs text-muted-foreground font-mono">
                <p><strong>Methodology:</strong> Error Level Analysis (ELA) identifies areas within an image that differ in compression levels. High-contrast white/red noise indicates potential digital modification or splicing.</p>
            </div>
        </Card>
    );
}
