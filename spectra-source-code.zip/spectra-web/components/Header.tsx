'use client';

import Link from 'next/link';
import { Search, User } from 'lucide-react';
import { Button, Input } from '@/components/ui';
import { createClient } from '@/utils/supabase/client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function Header() {
    const [user, setUser] = useState<any>(null);
    const supabase = createClient();
    const router = useRouter();

    useEffect(() => {
        const getUser = async () => {
            const { data: { user } } = await supabase.auth.getUser();
            setUser(user);
        };
        getUser();

        const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
            setUser(session?.user ?? null);
        });

        return () => subscription.unsubscribe();
    }, []);

    const handleSignOut = async () => {
        await supabase.auth.signOut();
        router.refresh();
    };

    const handleSignIn = async () => {
        const { error } = await supabase.auth.signInWithOAuth({
            provider: 'google',
            options: {
                redirectTo: `${location.origin}/auth/callback`,
            }
        });
        if (error) {
            console.error("Auth Error:", error);
            alert(`Authentication Error: ${error.message}\n\nPlease check your Supabase Dashboard to ensure the Google Provider is enabled.`);
        }
    };

    return (
        <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            < div className="container flex h-20 max-w-screen-2xl items-center justify-between">
                {/* Logo Area */}
                <div className="flex items-center gap-2">
                    < Link href="/" className="flex flex-col items-center">
                        < h1 className="font-serif text-4xl font-bold tracking-tighter text-primary text-glow">Spectra</h1>
                        < span className="text-[0.6rem] uppercase tracking-[0.2em] text-muted-foreground">Smart Media Gazette</span>
                    </Link >
                </div >

                {/* Navigation & Search */}
                < div className="flex flex-1 items-center justify-center gap-8 md:justify-end md:gap-4">
                    < nav className="hidden md:flex gap-6 text-sm font-medium tracking-wide uppercase text-muted-foreground">
                        < Link href="#" className="hover:text-foreground transition-colors">Geopolitics</Link>
                        < Link href="#" className="hover:text-foreground transition-colors">Silicon</Link>
                        < Link href="#" className="hover:text-foreground transition-colors">Biosphere</Link>
                    </nav >
                    <div className="relative w-full max-w-xs hidden md:block">
                        < Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                        < Input placeholder="Investigate headlines..." className="pl-8 bg-transparent border-b border-t-0 border-x-0 rounded-none focus-visible:ring-0 focus-visible:border-primary px-0" />
                    </div >

                    {/* User Auth */}
                    < div className="flex items-center gap-2">
                        {
                            user ? (
                                <Button variant="ghost" size="sm" onClick={handleSignOut} className="flex gap-2">
                                    < img src={user.user_metadata.avatar_url} alt="User" className="h-6 w-6 rounded-full" />
                                    < span className="hidden sm:inline-block">Sign Out</span>
                                </Button >
                            ) : (
                                <Button variant="ghost" size="icon" onClick={handleSignIn}>
                                    < User className="h-5 w-5" />
                                </Button >
                            )
                        }
                    </div >
                </div >
            </div >
        </header >
    );
}
